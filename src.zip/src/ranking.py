import pandas as pd

# Load returns data
df = pd.read_csv(
    "data/returns.csv",
    index_col=0
)

# Latest stock returns
latest_returns = df.iloc[-1]

# Rank stocks
ranked = latest_returns.sort_values(
    ascending=False
)

# Top outperformers
print("\nTOP OUTPERFORMERS\n")

print(ranked.head())

# Top underperformers
print("\nTOP UNDERPERFORMERS\n")

print(ranked.tail())