import pandas as pd

# Load returns data
df = pd.read_csv("data/returns.csv", index_col=0)

stocks = df.columns

# Create advanced features
for stock in stocks:

    # Previous day return
    df[f"{stock}_lag1"] = df[stock].shift(1)

    # Two day lag
    df[f"{stock}_lag2"] = df[stock].shift(2)

    # 5-day moving average
    df[f"{stock}_rolling_mean"] = (
        df[stock].rolling(5).mean()
    )

    # Volatility
    df[f"{stock}_volatility"] = (
        df[stock].rolling(5).std()
    )

# Remove missing values
df.dropna(inplace=True)

# Save features
df.to_csv("data/features.csv")

print("Feature Engineering Completed")

print(df.head())