import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import os

# Create outputs folder if not exists
os.makedirs("outputs", exist_ok=True)

# Load returns data
data = pd.read_csv("data/returns.csv", index_col=0)

# Calculate stock relationships
correlation_matrix = data.corr()

print("\nDependency Scores:\n")
print(correlation_matrix)

# Save dependency scores
correlation_matrix.to_csv(
    "data/dependency_scores.csv"
)

# Create heatmap
plt.figure(figsize=(12, 8))

sns.heatmap(
    correlation_matrix,
    annot=True,
    cmap="coolwarm"
)

plt.title("Cross Asset Dependency Heatmap")

# Save heatmap
plt.savefig("outputs/heatmap.png")

# Show chart
plt.show()

print("\nHeatmap saved successfully")