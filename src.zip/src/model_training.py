import pandas as pd

from sklearn.model_selection import train_test_split

from sklearn.ensemble import RandomForestRegressor

from sklearn.metrics import (
    mean_squared_error,
    mean_absolute_error,
    r2_score
)

# Load feature engineered data
df = pd.read_csv(
    "data/features.csv",
    index_col=0
)

# Target stock
target_stock = "AAPL"

# Predict next-day return
df["target"] = df[target_stock].shift(-1)

# Remove missing values
df.dropna(inplace=True)

# Features
X = df.drop(columns=["target"])

# Target
y = df["target"]

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    shuffle=False
)

# Create model
model = RandomForestRegressor(
    n_estimators=100,
    random_state=42
)

# Train model
model.fit(X_train, y_train)

# Predictions
predictions = model.predict(X_test)

# Evaluation metrics
rmse = mean_squared_error(
    y_test,
    predictions
) ** 0.5

mae = mean_absolute_error(
    y_test,
    predictions
)

r2 = r2_score(
    y_test,
    predictions
)

# Print results
print("\nMODEL EVALUATION\n")

print("RMSE:", rmse)

print("MAE:", mae)

print("R2 Score:", r2)

# Predict future return
latest_prediction = model.predict(
    X.tail(1)
)

print(
    "\nPredicted Next-Day Return:",
    latest_prediction[0]
)