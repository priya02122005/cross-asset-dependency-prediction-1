import pandas as pd

df = pd.read_csv("data/stocks.csv", index_col=0)

returns = df.pct_change()

returns.dropna(inplace=True)

returns.to_csv("data/returns.csv")

print("returns.csv created successfully")

print(returns.head())