// Cross Asset Prediction System

console.log(
    "Cross Asset Prediction System Loaded"
);

// Wait until page fully loads
document.addEventListener(
    "DOMContentLoaded",
    () => {

        // Select all cards
        const cards =
            document.querySelectorAll(".card");

        // Add hover effect
        cards.forEach(card => {

            card.addEventListener(
                "mouseover",
                () => {

                    card.style.transform =
                        "scale(1.03)";

                    card.style.transition =
                        "0.3s";

                    card.style.boxShadow =
                        "0px 0px 25px rgba(0,255,200,0.6)";
                }
            );

            card.addEventListener(
                "mouseout",
                () => {

                    card.style.transform =
                        "scale(1)";

                    card.style.boxShadow =
                        "0px 0px 15px rgba(0,0,0,0.3)";
                }
            );

        });

        // Prediction animation
        const prediction =
            document.querySelector(".prediction");

        if(prediction){

            prediction.style.opacity = "0";

            setTimeout(() => {

                prediction.style.transition =
                    "1s";

                prediction.style.opacity = "1";

            }, 300);
        }

        // Navbar active effect
        const navLinks =
            document.querySelectorAll("nav a");

        navLinks.forEach(link => {

            link.addEventListener(
                "mouseover",
                () => {

                    link.style.color =
                        "#00ffcc";
                }
            );

            link.addEventListener(
                "mouseout",
                () => {

                    link.style.color =
                        "white";
                }
            );

        });

        // Dynamic greeting
        const heading =
            document.querySelector("h1");

        if(heading){

            heading.style.animation =
                "fadeIn 1s ease";
        }

    }
);

// Add animation style dynamically
const style =
    document.createElement("style");

style.innerHTML = `
@keyframes fadeIn {

    from{
        opacity:0;
        transform:translateY(-20px);
    }

    to{
        opacity:1;
        transform:translateY(0);
    }
}
`;

document.head.appendChild(style);